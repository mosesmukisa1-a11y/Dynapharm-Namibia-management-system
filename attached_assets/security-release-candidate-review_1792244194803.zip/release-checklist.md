# Owner review checklist

Status: BLOCKED - DO NOT PUBLISH

- [x] One guarded, parameterized four-default production catalog read; closed.
- [x] Exact defaults retained; offline replay refused.
- [x] Full scoped 30-column canonical activity migration and merged provenance.
- [x] Nine schema contract/idempotency checks; no guessed canonical fixture.
- [x] Credential database checks 9/9.
- [x] Authenticated browser security workflow 29/29; synthetic data only.
- [x] Eight dispatch/cancel/reject concurrency/retry cases after note fix.
- [x] Unit suite 437/437; startup contracts 23/23.
- [x] Existing-dependency production build and bounded marker/canary checks.
- [x] Scans run without blanket rule suppression.
- [x] Owned cleanup confirmed; 14 ambiguous historical candidates untouched.
- [x] Exact candidate archive/755 source hashes prepared and checked.
- [ ] Complete repository legacy schema authority/convergence.
- [ ] Full database suite 378/378: currently 322 passed, 32 failed, 24 pending.
- [ ] Remaining 74 dynamic SQL locations and executor caller proof.
- [ ] Hostile tests for every reachable endpoint query family.
- [ ] Settled consultant page-rendering proof (separate from auth/API workflow).
- [ ] Genuine owner clean installation and sanitized result.

Follow dependency and code-only rollback boundaries in report.md.
No item, completed test or status authorizes production actions.
