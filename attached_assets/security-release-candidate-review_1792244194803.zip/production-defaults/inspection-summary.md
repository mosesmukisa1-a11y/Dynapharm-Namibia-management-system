# Final default-expression capture

One fixed parameterized catalog SELECT completed. Active transaction read-only
was on; recovery was true. Four exact default expressions captured. No business
rows read. No production modification. Access ended and replay prohibited.
Provider physical socket teardown is not independently observable.

- consultation_status: `'none'::character varying`
- prescription_status: `'none'::character varying`
- reporting_status: `'posted'::character varying`
- stock_status: `'not_required'::character varying`

Captured at: 2026-10-17T12:57:18.139567+00:00
