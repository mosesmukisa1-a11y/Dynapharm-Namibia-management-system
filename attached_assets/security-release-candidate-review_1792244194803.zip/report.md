# Final default capture and offline release verification

## BLOCKED - DO NOT PUBLISH

Completed on 2026-10-17. No publication, production migration, production repair,
configured service restart, credential rotation, or production worker action.

The four formerly redacted defaults are now captured and the complete scoped
activity-table migration passes its contract. The complete release gate does
**not** pass: the final repository-only database run is **322/378 passed,
32 failed, 24 pending**. The generic SQL executor is not cleared; **74** of the
original 182 dynamic locations remain unresolved. Clean installation has not run.

## 1. Single authorized production operation — PASS, CLOSED

Evidence: `production-defaults/` and the original
`generated-artifacts/production-schema-defaults-final/`.

- Exactly one fixed, parameterized managed production catalog SELECT.
- Query ID: `final-four-status-defaults-v1`.
- SQL SHA-256:
  `091111e517307bda81cec3e220e461188316528cf84793b0a6117b8fd83dfa2c`.
- Captured at **2026-10-17T12:57:18.139567+00:00**
  (**14:57:18 Africa/Windhoek**, UTC+02).
- Active transaction read-only: **on**; recovery: **true**; guard allowed: **true**.
- Provider completed successfully, exit code 0.
- Bound scope: public.branch_activity_transactions and exactly stock_status,
  prescription_status, consultation_status, reporting_status.
- Explicit relation sources: pg_catalog.pg_namespace, pg_class, pg_attribute,
  pg_attrdef. Only these four defaults use pg_get_expr.
- No application rows, unrelated columns, identity/role/privilege queries,
  preflight SQL, transaction controls, SET, DDL, DML, or retry.
- Authorization fingerprint, start/expiry, immutable query checksum, count zero,
  and exact allowlist were persisted before reservation/invocation.
- The durable journal records count one, provider completion, access ended,
  replay prohibited, and additional managed calls forbidden.
- Offline re-preparation was refused and the journal remained byte-identical.
  This verification did not invoke the provider.
- Provider completion is observed; physical pooled socket teardown is not
  independently observable and is not claimed.

Exact captured expressions, with owner-authorized literal preservation:

| Column | Default |
|---|---|
| stock_status | `'not_required'::character varying` |
| prescription_status | `'none'::character varying` |
| consultation_status | `'none'::character varying` |
| reporting_status | `'posted'::character varying` |

The CSV-wrapped JSON response was decoded offline, never re-queried to repair
parsing. No credentials, raw production database identity, host, username,
certificate, connection string, or provider secret was saved.

## 2. Canonical migration and provenance — scoped PASS

`migrations/039_canonical_branch_activity_transactions.sql` preserves the captured
30 columns in order, exact native types/lengths/defaults/nullability, primary
key, three secondary indexes plus primary index, and ordinary non-partitioned
table behavior. Captured scope has no foreign/check/additional unique constraints,
sequences, generated columns, or identity columns. None were invented.

`verify-captured-canonical-contract.mjs` merges only the four redacted expressions
into the earlier catalog evidence and compares all 30 contract tuples, constraint
definitions, index definitions, partition state, and identity/generated evidence.
See `merged-activity-schema.json` and `captured-contract-verification.json`.

These are two separately authorized capture times, not a contemporaneous
whole-schema snapshot. Original earlier evidence is retained unchanged.

`test-canonical-schema-owned.mjs` applied the repository users prerequisite and
migrations 036–039 to a newly owned, empty private cluster. It compared scoped
columns, types/defaults/nullability, identity/generated attributes, relation kind,
constraint definitions/validation/deferrability, index definitions/validity and
predicates, then applied the same migrations again and compared the snapshots.
**Nine checks passed**. Ownership and per-attempt cleanup files are retained.

Dependency order:

1. Existing repository users migration, then users.additional_roles (038).
2. Canonical branches (036), then delivery schema: towns, delivery_distances,
   online_orders, preserving its repository foreign keys.
3. Canonical branch_distributor_profit (037), then the repository linked-reversal
   schema batch that alters profit before creating stock_linked_reversals.
4. Canonical branch_activity_transactions (039), before activity-dependent use.

The six-object source-presence inventory has zero source-presence blockers.
That is **not** certification that every legacy application object is defined.
The full repository-only schema still has 19 unresolved DDL statements.

## 3. Fresh repository-only database gate — FAIL

No development/production schema clone or hand-built canonical business table
was used as a substitute. Each fixture starts a newly owned loopback cluster.
The complete suite then uses a separate owned empty-schema clone per test file.
Only repository migrations/static schema definitions construct its schema.

Incremental results are retained:

| Attempt | Passed | Failed | Pending | Outcome |
|---|---:|---:|---:|---|
| Initial repository fixture | 308 | 46 | 24 | FAIL; old wrapper incorrectly exited 0 |
| DDL/seed separation corrected | 317 | 37 | 24 | FAIL; wrapper correctly exits nonzero |
| Final, after dispatch-note fix | **322** | **32** | **24** | **FAIL**, nonzero exit |

The final run is
`fixture-runs/4c5c5de0-354c-4753-93bf-88708661b9c9/`.
`database-check-matrix.json` lists every one of the 378 named checks and result.
The separate current credential suite passed **9/9**, zero failures/pending.

### Root causes and bounded conclusions

1. **Fixture bug fixed:** backend/create_delivery_tables.sql mixes DDL and
   reference seeds. Sending that entire file in one query made a seed foreign-key
   failure roll back the schema batch. The fixture now lexically splits exact
   repository statements and selects schema DDL rather than executing those seeds.
   PostgreSQL dollar quoting, quoted semicolons, and nested comments are tested.
   This restored online_orders without inventing its definition.
2. **Fixture bug fixed:** a failed suite was recorded but not propagated to the
   fixture process exit code. Any failed database subprocess now makes the
   wrapper exit nonzero. Earlier failed evidence is not replaced with a pass.
3. **Confirmed dispatch defect fixed:** api/stock/transfers.js:createDispatchNote
   used `ON CONFLICT (transfer_id)` although the repository dispatch_notes schema
   has no corresponding unique constraint. The final owned diagnostics no longer
   show that 42P10 error.
4. **Canonical authority remains missing:** products, field_program_requests and
   hr_staff_change_requests have no complete repository CREATE TABLE definition
   established by this phase. Related product_images/file_uploads DDL therefore
   cannot converge; a notify_change dependency is also unresolved. These were
   not reconstructed from handler field names or production business data.
5. Actual owned query diagnostics establish missing **products** (42P01), missing
   hr_leave_requests.**notes** (42703), and further 42703 statements whose first
   query target is stock_batches. The exact missing column for those latter
   errors is **NOT VERIFIED**; safe diagnostics retain code/target/query checksum,
   not parameter values or unrestricted database error detail.
6. The GM fixture now explicitly refuses an absent authoritative table rather
   than producing misleading `INSERT INTO table()` syntax from an empty catalog
   result.
7. All **24 pending checks** are blocked by products: country-distribution setup
   (4), lifecycle setup (9), and price-list beforeAll cleanup (11). They are not
   counted as passed or silently waived.
8. There are **32 failed assertions** across sale recovery/evidence, GM decisions,
   remaining stock verification, stock cost lifecycle, alert policy, daily
   campaign reporting and import partial-failure suites. Some are downstream of
   missing schema/failed sales. Not all are conclusively traced to one cause;
   they remain release blockers, not 32 newly proven production defects.

### Dispatch-note fix and regression — PASS

API: `/api/stock/transfers`; function: `createDispatchNote`.

The function uses withTransaction, locks the existing stock_transfers parent,
selects the latest existing note under lock, and updates that one note or inserts
one if absent. SQL and values remain separate static bindings. No migration,
assumed unique index, deletion of old notes, or historical cleanup is required.
Its helper joins the existing request transaction rather than posting a second
stock transaction.

The real owned database/API concurrency suite passed **8/8**:
warehouse and branch sources, dispatch versus cancel/reject, either winner,
waiting loser, retry behavior, note count/status, stock/movement/allocation
balances, and preserved source layers. Original historical duplicate notes are
not deleted or merged. See the transfer suite entries in the 378-check matrix.

## 4. Authenticated browser security — PASS for tested workflow

One testing pass ran the owned fixture through actual staff login and session
middleware, using newly generated synthetic credentials held in memory and sent
to its browser child through IPC. No main preview or configured database was used.

**29 browser workflow assertions passed**, including:

- Temporary password login, restricted-session 403, explicit replacement POST
  with no-store, sign-out 401, rejection of the old temporary credential.
- Permanent login/reload and authenticated auth/me 200.
- Anonymous reset 401, consultant reset 403.
- Assigned client history 200 and cross-branch history 403.
- Rendered admin reset form, two successful explicit POSTs, masked credential
  input, affected-session invalidation 401, unrelated/admin session continuity.
- Reset credential restricted login and one-use replay rejection 401.
- Seven private/source/environment/dependency path denials, HTTP 404.

Run: `fixture-runs/3d64110b-a5a6-4d7a-95a8-dcbeee38c93a/`.
The browser run predates only the separate dispatch-note change and subsequent
diagnostic/tooling changes; no authentication or UI implementation changed.
It does not establish stock lifecycle completion.

### Page rendering is separate

- Admin reset completion screenshot: rendered synthetic staff screen, **PASS**.
- Consultant reload screenshot: transient loading state, **NOT VERIFIED** as
  complete portal rendering. Authenticated reload/API assertions passed; that is
  not proof of settled page rendering.
- Both screenshots were visually inspected; neither exposes a credential.
- Red/white theme, navigation and existing history features were not redesigned.

## 5. Remaining SQL review — PARTIAL, executor NOT CLEARED

All 182 original review locations remain enumerated with current source checksums,
file/line/function, call family and classification. Import ancestry was added for
possible API modules/server reachability. Changed transfer line positions are
reported against the current source inventory, not stale line numbers.

| Classification | Locations |
|---|---:|
| Static SQL with bound values / locally proven fixed structure | 106 |
| Fixed internal constant | 2 |
| Unresolved blocker | **74** |

This resolves **26 more** of the previous 100 unresolved locations at the bounded
local syntax/data-shape proof level. New proofs cover fixed reassignments, native
numeric placeholder counters/iterator indexes, fixed trimming/logical branches,
guarded array push positions, and the reviewed business-date helper with fixed
structure arguments. Hostile replacement/method mutation cases remain rejected.

See `sql-caller-review.json` and `sql-family-reachability.json`. Import reachability
is not a full function-level taint proof. Reflective imports, alias/callback
propagation and the remaining wrappers still require review. The generic executor
is **not** cleared. No rule was globally suppressed.

Five actual PostgreSQL shared-builder sentinel checks passed: hostile bound value
stays data, structural table/column/order attacks are rejected, sentinel retained.
These checks do **not** replace hostile-input tests for every reachable endpoint
family. That requested endpoint-family coverage remains **NOT VERIFIED**.

## 6. Other final verification

| Check | Result |
|---|---|
| Full unit suite | **437/437 PASS**, 69 files |
| Startup contracts | **23/23 PASS**, zero skips |
| Complete canonical scoped contracts/idempotency | **9 PASS** |
| Credential DB | **9/9 PASS** |
| Full DB | **322/378 PASS; 32 FAIL; 24 pending/BLOCKED** |
| Dispatch concurrency/retry | **8/8 PASS** within full DB suite |
| Strict code-only private launcher and compatibility health | **PASS**, HTTP 200 |
| Authenticated security browser workflow | **29/29 PASS** |
| Production frontend build | **PASS**, existing dependencies |
| Real harmless source-map canary denial/removal | **PASS**, component test |
| Synthetic marker absence in sampled bundles/responses/logs | **PASS**, bounded scope |
| Every handler/error output path | **NOT VERIFIED** |
| Exact source candidate archive/hash verification | **PASS** |
| Genuine dependency clean installation | **NOT VERIFIED**, not attempted |

The code-only profile disables startup schema sync/seeds, scheduler, digest and
all production worker flags. No configured application workflow was restarted.
Synthetic one-shot DB worker checks are isolated tests, not deployment activation.

### Managed scans

- Dependency: **2 HIGH** xlsx advisories. Existing upstream patched-version caveat
  remains; no dependency replacement, advisory suppression or blanket clearance.
- SAST: **81 findings** — **73 CRITICAL, 5 HIGH, 3 MEDIUM**, scan complete.
  Counts are scanner findings, not 81 confirmed exploits. The unresolved executor
  and 74 callers remain blockers.
- Privacy/dataflow: **0 findings**; not proof of all-handler privacy.
- Credential scan: **1,195 current source files**, **8,838 reachable Git blobs**;
  12 current candidates (8 test placeholders, 4 false positives);
  **1,670 historical candidates** remain.
- The owner-supplied earlier published source tree has 68 candidates, 57 carrying
  the scanner's exposure classification. That local historical tree is **not a
  fresh validation of current live credentials**. No values, reusable password
  digests, production credential checks, rotation or Git history rewrite.

### Ownership and cleanup

Ownership is recorded before initdb/database creation. New fixture paths are
selected and journaled before directory creation. Canonical-contract attempts now
retain individual ownership IDs rather than overwriting the only record.

Current known fixtures have awaited database drops/cluster stops and filesystem
absence checks; per-suite database ownership cleanup records are retained.
Browser child/application shutdown and private directory removal are recorded.
Source-map canaries and temporary archive preparation directories were removed.
The **14 ambiguous historical database candidates were not inspected or deleted**.
See `owned-cleanup-verification.json`.

## 7. Candidate, migration plan and rollback

Exact candidate archive:
`generated-artifacts/security-remediation-final/exact-candidate-source.tar`

SHA-256:
`8ce82fac9397435805fa82b17be9c6eca62720e61e8cdeb75c766bbb3c533527`

The manifest verifies **755 current source files**, including the new migration,
full contract, tooling/tests and dispatch fix. No existing node_modules was copied.
Current hashes match the archive manifest. Generated evidence, uploads, private
runtime material, environment files and Git history are excluded.

This preparation is not a clean install. The sanitized clean-install result says
NOT VERIFIED, installationAttempted=false. Owner-only command:

```sh
cd /home/runner/workspace
node scripts/security-final-clean-gate.mjs --owner-manual
```

Even a successful install cannot waive the 378-check failure or SQL blockers.

Migration plan: keep 036–039 as repository/offline-test material. Resolve missing
legacy canonical authority and the remaining review/test failures first. Rebuild
an empty owned schema in the dependency order above and pass the complete suite.
An existing incompatible table is not silently rewritten by IF NOT EXISTS; stop
and review mismatches. There is no production migration or publication authority.

Rollback: code-only review of this phase's listed changes. Preserve earlier
completed stock, credentials, history, navigation and red/white UI fixes. Revert
only an identified phase regression through a reviewed code diff/checkpoint.
Do not DROP production objects, reverse live balances, delete historical notes,
apply backfills, rotate live credentials, invalidate live sessions or restart
services. No production database rollback was needed.

## 8. Changed files

- `api/stock/transfers.js` — transaction/parent-lock note creation without an
  unsupported conflict target; original stock reservation/receipt behavior kept.
- `migrations/039_canonical_branch_activity_transactions.sql`.
- `tests/fixtures/canonical-schema-contract.json`.
- `scripts/lib/final-default-expression-query.mjs`.
- `scripts/prepare-final-default-operation.mjs`.
- `scripts/close-final-default-evidence.mjs`.
- `scripts/verify-captured-canonical-contract.mjs`.
- `scripts/test-canonical-schema-owned.mjs`.
- `scripts/lib/repository-ddl.mjs`.
- `scripts/lib/owned-query-diagnostics.mjs`.
- `scripts/security-closure-fixture.mjs`.
- `scripts/lib/sql-caller-proof.mjs`.
- `scripts/review-final-sql-callers.mjs`.
- `scripts/trace-final-sql-families.mjs`.
- `scripts/security-final-inventory.mjs`.
- `scripts/audit-credential-exposure.py`.
- `scripts/security-final-output-rehearsal.mjs`.
- `tests/final-default-expression-query.unit.test.js`.
- `tests/repository-ddl.unit.test.js`.
- `tests/sql-caller-proof.unit.test.js`.
- `tests/gm-decisions.spec.js` — explicit missing-table fixture failure.
- `.agents/memory/audit-tool-runtime.md` — bounded-scope verification lesson;
  excluded from deployment candidate.

Generated evidence/authorization artifacts are not application source.
`changed-files.json` also records working-tree state; automatic checkpoints may
move earlier phase changes into HEAD, so that file alone is not the phase diff.

## 9. Exact offline test/review commands

```sh
node scripts/close-final-default-evidence.mjs
node scripts/verify-captured-canonical-contract.mjs
node scripts/test-canonical-schema-owned.mjs
node scripts/security-closure-fixture.mjs --database-suites --query-diagnostics
node scripts/security-closure-fixture.mjs --schema-only
node scripts/security-final-inventory.mjs
node scripts/review-final-sql-callers.mjs
node scripts/trace-final-sql-families.mjs
node node_modules/vitest/vitest.mjs run --project unit
PREDEPLOY_TARGET_ROOT="$PWD" node --test scripts/predeployment-startup-contract.test.mjs
node scripts/security-final-sql-rehearsal.mjs
node scripts/security-final-output-rehearsal.mjs
python scripts/audit-credential-exposure.py
node scripts/security-final-clean-gate.mjs --prepare
```

The owned browser pass was run once by the tester:

```sh
node scripts/security-closure-fixture.mjs
```

Managed scan callbacks, not production SQL: runDependencyAudit(), runSastScan(),
runHoundDogScan(). The one production query is preserved verbatim in
production-defaults/query-definition.json for review, **not execution/replay**.

The earlier preparation command is terminal and refuses replay:

```sh
node scripts/prepare-final-default-operation.mjs
```

## Final safety record

Managed production SQL operations in this phase: 1
Production business rows read: NO
Production database modified: NO
Production migration applied: NO
Production passwords rotated: NO
Production sessions invalidated: NO
Production environment modified: NO
Production restarted: NO
Production scheduler stopped: NO
Production worker activated: NO
Production published: NO
